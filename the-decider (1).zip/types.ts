
export enum NodeType {
  QUESTION = 'QUESTION',
  VERDICT = 'VERDICT'
}

export enum VerdictLevel {
  BUY = 'BUY',
  WAIT = 'WAIT',
  SAVE = 'SAVE'
}

export interface Choice {
  label: string;
  nextNodeId: string;
  description?: string;
  scoreImpact?: number;
}

export interface QuizNode {
  id: string;
  type: NodeType;
  // Question props
  question?: string;
  choices?: Choice[];
  // Verdict props
  title?: string;
  verdictLevel?: VerdictLevel;
  content?: string;
  recommendations?: Recommendation[];
}

export interface Recommendation {
  name: string;
  price: string;
  url: string;
  imageUrl: string;
  pros: string[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  startNodeId: string;
}

export interface QuizState {
  categoryId: string | null;
  currentNodeId: string | null;
  score: number;
  history: string[];
}
