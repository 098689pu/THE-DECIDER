import { Category, QuizNode, NodeType, VerdictLevel } from './types';

export const CATEGORIES: Category[] = [
  {
    id: '3d-printer',
    name: '3D Printer',
    icon: '🏗️',
    description: 'FDM or Resin? Practical or creative? Let us narrow it down.',
    startNodeId: '3d_q1'
  },
  {
    id: 'mech-keyboard',
    name: 'Mechanical Keyboard',
    icon: '⌨️',
    description: 'Custom builds, switches, and layouts for the ultimate typing experience.',
    startNodeId: 'kb_q1'
  },
  {
    id: 'espresso',
    name: 'Espresso Machine',
    icon: '☕',
    description: 'From manual levers to super-automatics. Find your perfect brew.',
    startNodeId: 'esp_q1'
  },
  {
    id: 'gaming-mouse',
    name: 'Gaming Mouse',
    icon: '🖱️',
    description: 'Lightweight speed or wireless freedom? Find your perfect sensor and shape.',
    startNodeId: 'mouse_q1'
  },
  {
    id: 'backpack',
    name: 'Backpack',
    icon: '🎒',
    description: 'Travel, work, or trail? Find the right capacity and harness for your back.',
    startNodeId: 'pack_q1'
  }
];

export const QUIZ_NODES: Record<string, QuizNode> = {
  // 3D PRINTER PATH
  '3d_q1': {
    id: '3d_q1',
    type: NodeType.QUESTION,
    question: 'Do you enjoy tinkering with hardware and fixing things when they break?',
    choices: [
      { label: 'Yes, it is part of the fun!', nextNodeId: '3d_q2', scoreImpact: 2 },
      { label: 'No, I just want it to work.', nextNodeId: '3d_save_1', scoreImpact: -5 }
    ]
  },
  '3d_q2': {
    id: '3d_q2',
    type: NodeType.QUESTION,
    question: 'Do you have a well-ventilated space (garage or dedicated workshop)?',
    choices: [
      { label: 'Yes, plenty of air.', nextNodeId: '3d_q3', scoreImpact: 1 },
      { label: 'No, only my bedroom/office.', nextNodeId: '3d_wait_1', scoreImpact: 0 }
    ]
  },
  '3d_q3': {
    id: '3d_q3',
    type: NodeType.QUESTION,
    question: 'What is your primary use case?',
    choices: [
      { label: 'Functional parts and tools.', nextNodeId: '3d_buy_fdm', scoreImpact: 3 },
      { label: 'Highly detailed miniatures/figures.', nextNodeId: '3d_buy_resin', scoreImpact: 3 }
    ]
  },
  '3d_buy_fdm': {
    id: '3d_buy_fdm',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Buy a Bambu Lab or Prusa (FDM)',
    content: 'You have the mindset and the space. An FDM printer is perfect for functional prototypes and large durable parts.',
    recommendations: [
      {
        name: 'Bambu Lab P1S',
        price: '$599',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/p1s/400/300',
        pros: ['Extremely fast', 'Reliable', 'Great out of the box']
      },
      {
        name: 'Prusa MK4',
        price: '$799',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mk4/400/300',
        pros: ['Open source', 'Workhorse longevity', 'Amazing support']
      }
    ]
  },
  '3d_buy_resin': {
    id: '3d_buy_resin',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Go with a 4K/8K Resin Printer',
    content: 'For miniatures, nothing beats resin. Just remember you need a wash and cure station!',
    recommendations: [
      {
        name: 'Elegoo Mars 4',
        price: '$280',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mars4/400/300',
        pros: ['Detail level is insane', 'Affordable entry price']
      }
    ]
  },
  '3d_wait_1': {
    id: '3d_wait_1',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.WAIT,
    title: 'Wait & Reconsider Space',
    content: '3D printers (especially resin) produce fumes and noise. Using one in a bedroom without proper ventilation is a health risk. Look into enclosures or air scrubbers before buying.',
    recommendations: []
  },
  '3d_save_1': {
    id: '3d_save_1',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.SAVE,
    title: 'Save Your Money',
    content: '3D printing is as much about maintaining the machine as it is about the prints. If you hate tinkering, you will likely find the experience frustrating. Use a local printing service like Craftcloud instead.',
    recommendations: []
  },

  // MECHANICAL KEYBOARD PATH
  'kb_q1': {
    id: 'kb_q1',
    type: NodeType.QUESTION,
    question: 'How much time are you willing to spend researching and building?',
    choices: [
      { label: 'Hours. I want custom everything.', nextNodeId: 'kb_q2', scoreImpact: 3 },
      { label: 'Just a few minutes. Give me a pre-built.', nextNodeId: 'kb_prebuilt', scoreImpact: 1 }
    ]
  },
  'kb_q2': {
    id: 'kb_q2',
    type: NodeType.QUESTION,
    question: 'Do you have a dedicated budget for "Group Buys" (waiting 6-12 months)?',
    choices: [
      { label: 'Yes, I am patient.', nextNodeId: 'kb_high_end', scoreImpact: 5 },
      { label: 'No, I want it in 2 days.', nextNodeId: 'kb_budget_custom', scoreImpact: 2 }
    ]
  },
  'kb_prebuilt': {
    id: 'kb_prebuilt',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Get a Premium Pre-built',
    content: 'You want quality without the labor. Brands like Keychron or MonsGeek offer amazing value out of the box.',
    recommendations: [
      {
        name: 'Keychron Q1 Pro',
        price: '$199',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/kb1/400/300',
        pros: ['Full aluminum', 'Wireless', 'Hot-swappable']
      }
    ]
  },
  'kb_high_end': {
    id: 'kb_high_end',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Enter the Custom World',
    content: 'You are ready for the deep end. Look for current group buys on Geekhack or vendors like CannonKeys.',
    recommendations: []
  },
  'kb_budget_custom': {
    id: 'kb_budget_custom',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Entry Level Custom',
    content: 'Get a barebones kit and choose your own switches and keycaps. It is the perfect gateway drug.',
    recommendations: [
      {
        name: 'Neo65',
        price: '$80 (Barebones)',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/kb2/400/300',
        pros: ['Insane value', 'Great sound profile']
      }
    ]
  },

  // ESPRESSO PATH
  'esp_q1': {
    id: 'esp_q1',
    type: NodeType.QUESTION,
    question: 'Do you already own a high-quality burr grinder?',
    choices: [
      { label: 'Yes, a good one.', nextNodeId: 'esp_q2', scoreImpact: 2 },
      { label: 'No, or I use pre-ground.', nextNodeId: 'esp_save_grinder', scoreImpact: -5 }
    ]
  },
  'esp_q2': {
    id: 'esp_q2',
    type: NodeType.QUESTION,
    question: 'How many milk-based drinks (lattes/cappuccinos) do you make per day?',
    choices: [
      { label: '3 or more. I need speed.', nextNodeId: 'esp_dual_boiler', scoreImpact: 4 },
      { label: 'Mostly straight espresso.', nextNodeId: 'esp_single_boiler', scoreImpact: 2 }
    ]
  },
  'esp_save_grinder': {
    id: 'esp_save_grinder',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.SAVE,
    title: 'Buy a Grinder First',
    content: 'Espresso machines are useless without a capable grinder. Spend your budget on a Baratza Encore ESP or a DF64 before even looking at machines.',
    recommendations: [
      {
        name: 'DF64 Gen 2',
        price: '$399',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/grind/400/300',
        pros: ['Flat burrs', 'Single dose', 'Unbeatable price']
      }
    ]
  },
  'esp_dual_boiler': {
    id: 'esp_dual_boiler',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Go Dual Boiler or HX',
    content: 'You need simultaneous steaming and brewing. Single boilers will slow you down and frustrate you.',
    recommendations: [
      {
        name: 'Profitec Pro 600',
        price: '$2300',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/coffee1/400/300',
        pros: ['Pressure profiling', 'Solid build']
      }
    ]
  },
  'esp_single_boiler': {
    id: 'esp_single_boiler',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Single Boiler is Enough',
    content: 'Since you drink mostly black coffee, a high-quality single boiler will save you money and bench space.',
    recommendations: [
      {
        name: 'Gaggia Classic Pro',
        price: '$450',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/coffee2/400/300',
        pros: ['Industry standard', 'Mod-friendly']
      }
    ]
  },

  // GAMING MOUSE PATH
  'mouse_q1': {
    id: 'mouse_q1',
    type: NodeType.QUESTION,
    question: 'What is your connection preference for high-stakes gaming?',
    choices: [
      { label: 'Wireless (Zero cables, freedom of movement)', nextNodeId: 'mouse_q2_wireless', scoreImpact: 2 },
      { label: 'Wired (Maximum reliability, lighter weight)', nextNodeId: 'mouse_q2_wired', scoreImpact: 1 }
    ]
  },
  'mouse_q2_wireless': {
    id: 'mouse_q2_wireless',
    type: NodeType.QUESTION,
    question: 'What matters most to you in a wireless sensor?',
    choices: [
      { label: 'Extreme Precision (26K+ DPI, 4K/8K Hz Polling)', nextNodeId: 'mouse_buy_pro_wireless', scoreImpact: 4 },
      { label: 'Casual Reliability (Budget-friendly, Good Battery)', nextNodeId: 'mouse_buy_budget_wireless', scoreImpact: 1 }
    ]
  },
  'mouse_q2_wired': {
    id: 'mouse_q2_wired',
    type: NodeType.QUESTION,
    question: 'Are you looking for ultra-lightweight for competitive shooters?',
    choices: [
      { label: 'Yes, as light as possible (under 60g).', nextNodeId: 'mouse_buy_wired_light', scoreImpact: 3 },
      { label: 'No, I prefer something balanced and ergonomic.', nextNodeId: 'mouse_buy_wired_ergo', scoreImpact: 1 }
    ]
  },
  'mouse_buy_pro_wireless': {
    id: 'mouse_buy_pro_wireless',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Get a Flagship Wireless Mouse',
    content: 'You demand the best. Modern wireless technology is now as fast as wired, with polling rates exceeding 4000Hz for the smoothest experience.',
    recommendations: [
      {
        name: 'Logitech G Pro X Superlight 2',
        price: '$159',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mouse1/400/300',
        pros: ['Used by pros', 'Extremely reliable', 'Great software']
      },
      {
        name: 'Razer DeathAdder V3 Pro',
        price: '$149',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mouse2/400/300',
        pros: ['Best-in-class sensor', 'Great for palm grip']
      }
    ]
  },
  'mouse_buy_budget_wireless': {
    id: 'mouse_buy_budget_wireless',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Affordable Wireless Power',
    content: 'You can get 95% of the performance for 40% of the price. Perfect for everyday gaming without the cable drag.',
    recommendations: [
      {
        name: 'Logitech G305 Lightspeed',
        price: '$49',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mouse3/400/300',
        pros: ['Incredible battery life', 'Cheap and reliable']
      }
    ]
  },
  'mouse_buy_wired_light': {
    id: 'mouse_buy_wired_light',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'The Ultralight Specialist',
    content: 'By sticking with a wire, you save weight on batteries and gain the most consistent response times available.',
    recommendations: [
      {
        name: 'Razer Viper 8KHz',
        price: '$79',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mouse4/400/300',
        pros: ['8000Hz polling rate', 'Ambidextrous shape']
      }
    ]
  },
  'mouse_buy_wired_ergo': {
    id: 'mouse_buy_wired_ergo',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Wired Comfort King',
    content: 'Stability and comfort are your priorities. A wired ergo mouse is a reliable companion for long gaming sessions.',
    recommendations: [
      {
        name: 'Zowie EC2-C',
        price: '$69',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/mouse5/400/300',
        pros: ['Legendary shape', 'No software needed']
      }
    ]
  },

  // BACKPACK PATH
  'pack_q1': {
    id: 'pack_q1',
    type: NodeType.QUESTION,
    question: 'What is the primary environment for your new pack?',
    choices: [
      { label: 'Travel (Airports, one-bagging, long trips)', nextNodeId: 'pack_q2_travel', scoreImpact: 3 },
      { label: 'EDC/Work (Office, commute, laptop carry)', nextNodeId: 'pack_q2_edc', scoreImpact: 2 },
      { label: 'Hiking/Outdoors (Trails, hydration, rugged terrain)', nextNodeId: 'pack_q2_hiking', scoreImpact: 2 }
    ]
  },
  'pack_q2_travel': {
    id: 'pack_q2_travel',
    type: NodeType.QUESTION,
    question: 'How much are you planning to carry?',
    choices: [
      { label: 'Minimalist (20L-30L, fits under the seat)', nextNodeId: 'pack_buy_travel_small', scoreImpact: 1 },
      { label: 'Full Trip (40L+, carry-on max)', nextNodeId: 'pack_buy_travel_large', scoreImpact: 3 }
    ]
  },
  'pack_q2_edc': {
    id: 'pack_q2_edc',
    type: NodeType.QUESTION,
    question: 'How much tech and organization do you need?',
    choices: [
      { label: 'Minimalist (Just a laptop and a jacket)', nextNodeId: 'pack_buy_edc_small', scoreImpact: 1 },
      { label: 'Professional Organised (Lots of pockets/cables)', nextNodeId: 'pack_buy_edc_tech', scoreImpact: 3 }
    ]
  },
  'pack_q2_hiking': {
    id: 'pack_q2_hiking',
    type: NodeType.QUESTION,
    question: 'How long are your typical sessions?',
    choices: [
      { label: 'Short Day Hikes (3-5 hours)', nextNodeId: 'pack_buy_hiking_day', scoreImpact: 1 },
      { label: 'All-Day or Light Overnight (8+ hours)', nextNodeId: 'pack_buy_hiking_technical', scoreImpact: 3 }
    ]
  },
  'pack_buy_travel_small': {
    id: 'pack_buy_travel_small',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'The Underseat One-Bagger',
    content: 'Perfect for weekend trips or for those who hate waiting at baggage claim. Compact but efficient.',
    recommendations: [
      {
        name: 'Aer Travel Pack 3 Small',
        price: '$229',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack1/400/300',
        pros: ['Great organization', 'Durable Cordura']
      }
    ]
  },
  'pack_buy_travel_large': {
    id: 'pack_buy_travel_large',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'The Carry-On Powerhouse',
    content: 'You want to maximize your cabin allowance. These packs offer 40-45L of space with comfortable harnesses.',
    recommendations: [
      {
        name: 'Osprey Farpoint 40',
        price: '$185',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack2/400/300',
        pros: ['Incredible harness system', 'Lifetime warranty']
      }
    ]
  },
  'pack_buy_edc_small': {
    id: 'pack_buy_edc_small',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Sleek Minimalist EDC',
    content: 'Focus on aesthetics and build quality without the bulk of unnecessary pockets.',
    recommendations: [
      {
        name: 'Bellroy Classic Backpack',
        price: '$149',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack3/400/300',
        pros: ['Beautiful materials', 'Clean silhouette']
      }
    ]
  },
  'pack_buy_edc_tech': {
    id: 'pack_buy_edc_tech',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'The Tech Commuter',
    content: 'Dedicated space for everything: laptop, tablet, power banks, and headphones.',
    recommendations: [
      {
        name: 'Peak Design Everyday Backpack',
        price: '$279',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack4/400/300',
        pros: ['Innovative side access', 'Camera-ready']
      }
    ]
  },
  'pack_buy_hiking_day': {
    id: 'pack_buy_hiking_day',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Lightweight Trail Pack',
    content: 'Focus on breathability and hydration. Small enough to stay out of your way.',
    recommendations: [
      {
        name: 'Osprey Daylite Plus',
        price: '$75',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack5/400/300',
        pros: ['Extremely breathable', 'Very light']
      }
    ]
  },
  'pack_buy_hiking_technical': {
    id: 'pack_buy_hiking_technical',
    type: NodeType.VERDICT,
    verdictLevel: VerdictLevel.BUY,
    title: 'Technical Daypack',
    content: 'Advanced suspension systems to carry more weight comfortably over many miles.',
    recommendations: [
      {
        name: 'Gregory Zulu 30',
        price: '$160',
        url: '#',
        imageUrl: 'https://picsum.photos/seed/pack6/400/300',
        pros: ['Adjustable torso', 'Suspended mesh back']
      }
    ]
  }
};
