
import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  ArrowRight, 
  Check, 
  ShoppingBag, 
  Clock, 
  ShieldX, 
  Info, 
  RotateCcw, 
  ChevronLeft, 
  PlusCircle, 
  AlertCircle, 
  ChevronRight,
  X,
  Loader2,
  ExternalLink,
  Sparkles,
  Search
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Category, 
  QuizNode, 
  NodeType, 
  VerdictLevel, 
  QuizState,
  Recommendation
} from './types';
import { CATEGORIES, QUIZ_NODES } from './quizData';

// --- Components ---

const Toast: React.FC<{ message: string; onClose: () => void }> = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-8 right-8 z-[100] animate-fade-in">
      <div className="bg-indigo-600 text-white px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-white/20">
        <Zap size={18} className="fill-white" />
        <span className="font-bold text-sm">{message}</span>
        <button onClick={onClose} className="hover:opacity-70"><X size={16} /></button>
      </div>
    </div>
  );
};

const Header: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => (
  <header className="py-6 px-6 border-b border-slate-800/50 bg-slate-950/80 sticky top-0 z-50 backdrop-blur-md">
    <div className="max-w-6xl mx-auto flex items-center justify-between">
      <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.location.reload()}>
        <div className="bg-indigo-600 p-2 rounded-lg">
          <Zap className="text-white w-6 h-6 fill-white" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight font-outfit text-white">THE DECIDER</h1>
      </div>
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button onClick={() => onNotify("Our algorithm is based on expert decision matrices.")} className="hover:text-white transition-colors">Algorithm</button>
        <button onClick={() => onNotify("AI Generation is now active.")} className="hover:text-white transition-colors flex items-center gap-1.5">
          <Sparkles size={14} className="text-indigo-400" /> Lab
        </button>
        <button onClick={() => onNotify("Support our independent tool developer!")} className="bg-white/5 border border-white/10 px-5 py-2 rounded-full hover:bg-white/10 transition-colors text-white font-bold">Donate</button>
      </nav>
    </div>
  </header>
);

const CategoryCard: React.FC<{ 
  category: Category; 
  onSelect: (id: string) => void 
}> = ({ category, onSelect }) => (
  <button 
    onClick={() => onSelect(category.id)}
    className="glass-card p-6 rounded-2xl text-left transition-all duration-300 hover:scale-[1.02] hover:border-indigo-500 group relative overflow-hidden focus:outline-none focus:ring-2 focus:ring-indigo-500"
  >
    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
      <span className="text-6xl">{category.icon}</span>
    </div>
    <div className="mb-4 text-4xl">{category.icon}</div>
    <h3 className="text-xl font-bold mb-2 text-white font-outfit">{category.name}</h3>
    <p className="text-slate-400 text-sm leading-relaxed line-clamp-2">{category.description}</p>
    <div className="mt-6 flex items-center gap-2 text-indigo-400 font-semibold text-sm group-hover:gap-3 transition-all">
      Start Decision Engine <ArrowRight size={16} />
    </div>
  </button>
);

const AffiliateBlock: React.FC<{ recommendations: Recommendation[] }> = ({ recommendations }) => {
  if (!recommendations || recommendations.length === 0) return null;
  return (
    <div className="mt-12 pt-12 border-t border-slate-800">
      <h4 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6 text-center">Recommended Gear</h4>
      <div className="grid md:grid-cols-2 gap-6">
        {recommendations.map((rec, i) => (
          <div key={i} className="glass-card rounded-xl overflow-hidden border-indigo-500/20 group">
            <div className="relative h-48 overflow-hidden bg-slate-900">
              <img src={rec.imageUrl} alt={rec.name} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="p-5">
              <div className="flex justify-between items-start mb-3">
                <h5 className="font-bold text-lg text-white">{rec.name}</h5>
                <span className="bg-indigo-600/20 text-indigo-400 px-2 py-1 rounded text-xs font-bold">{rec.price}</span>
              </div>
              <ul className="space-y-2 mb-6">
                {rec.pros.map((pro, j) => (
                  <li key={j} className="text-xs text-slate-400 flex items-center gap-2">
                    <Check size={12} className="text-emerald-500" /> {pro}
                  </li>
                ))}
              </ul>
              <a 
                href={rec.url} 
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full text-center bg-indigo-600 hover:bg-indigo-700 py-2.5 rounded-lg text-sm font-bold transition-colors text-white"
              >
                View Details <ExternalLink size={14} />
              </a>
            </div>
          </div>
        ))}
      </div>
      <p className="mt-8 text-[10px] text-slate-600 italic text-center">
        Disclosure: This page contains affiliate links. We may earn a commission if you make a purchase.
      </p>
    </div>
  );
};

// --- Main App Logic ---

export default function App() {
  const [state, setState] = useState<QuizState>({
    categoryId: null,
    currentNodeId: null,
    score: 0,
    history: []
  });
  
  const [dynamicNodes, setDynamicNodes] = useState<Record<string, QuizNode>>({});
  const [dynamicCategories, setDynamicCategories] = useState<Category[]>([]);
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiInput, setAiInput] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  const handleCategorySelect = (id: string) => {
    const allCategories = [...CATEGORIES, ...dynamicCategories];
    const category = allCategories.find(c => c.id === id);
    if (category) {
      setState({
        categoryId: id,
        currentNodeId: category.startNodeId,
        score: 0,
        history: []
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleAIGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim()) return;

    setLoadingAI(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Create a 3-question decision tree for the hobby: "${aiInput}". 
        Return a JSON object that strictly follows these rules:
        - Must contain exactly 3 questions and 3 final verdicts (BUY, WAIT, SAVE).
        - Each choice must lead to a valid nextNodeId.
        - The root category id should be "dynamic-${Date.now()}".
        - The questions should be highly logical and binary (Yes/No).
        - The output must be valid JSON matching the app's internal Node structure.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              category: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  name: { type: Type.STRING },
                  icon: { type: Type.STRING },
                  description: { type: Type.STRING },
                  startNodeId: { type: Type.STRING }
                },
                required: ["id", "name", "icon", "description", "startNodeId"]
              },
              nodes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    type: { type: Type.STRING, description: "QUESTION or VERDICT" },
                    question: { type: Type.STRING },
                    choices: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          label: { type: Type.STRING },
                          nextNodeId: { type: Type.STRING },
                          scoreImpact: { type: Type.NUMBER }
                        },
                        required: ["label", "nextNodeId"]
                      }
                    },
                    verdictLevel: { type: Type.STRING, description: "BUY, WAIT, or SAVE" },
                    title: { type: Type.STRING },
                    content: { type: Type.STRING }
                  },
                  required: ["id", "type"]
                }
              }
            },
            required: ["category", "nodes"]
          }
        }
      });

      const data = JSON.parse(response.text);
      
      // Map nodes to dictionary
      const newNodes: Record<string, QuizNode> = {};
      data.nodes.forEach((n: any) => {
        newNodes[n.id] = n;
      });

      setDynamicNodes(prev => ({ ...prev, ...newNodes }));
      setDynamicCategories(prev => [data.category, ...prev]);
      handleCategorySelect(data.category.id);
      setAiInput('');
      setToast(`AI generated a decision matrix for ${data.category.name}!`);
    } catch (err) {
      console.error(err);
      setToast("AI failed to generate. Please try a different hobby.");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleChoiceSelect = (nextNodeId: string, impact: number = 0) => {
    setState(prev => ({
      ...prev,
      currentNodeId: nextNodeId,
      score: prev.score + impact,
      history: [...prev.history, prev.currentNodeId!]
    }));
  };

  const handleBack = () => {
    if (state.history.length === 0) {
      handleReset();
    } else {
      const newHistory = [...state.history];
      const prevNodeId = newHistory.pop();
      setState(prev => ({
        ...prev,
        currentNodeId: prevNodeId || null,
        history: newHistory,
      }));
    }
  };

  const handleReset = () => {
    setState({
      categoryId: null,
      currentNodeId: null,
      score: 0,
      history: []
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const allNodes = { ...QUIZ_NODES, ...dynamicNodes };
  const allCategories = [...CATEGORIES, ...dynamicCategories];
  
  const activeNode = state.currentNodeId ? allNodes[state.currentNodeId] : null;
  const activeCategory = state.categoryId ? allCategories.find(c => c.id === state.categoryId) : null;

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col selection:bg-indigo-500 selection:text-white text-slate-200">
      <Header onNotify={(msg) => setToast(msg)} />
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}

      <main className="flex-1 max-w-6xl mx-auto w-full px-6 py-12 md:py-20">
        {!state.categoryId ? (
          <div className="animate-fade-in">
            {/* Hero Section */}
            <div className="text-center max-w-3xl mx-auto mb-20">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black uppercase tracking-widest mb-6">
                <Sparkles size={14} className="fill-indigo-400" /> AI-Powered Decision Lab
              </div>
              <h2 className="text-5xl md:text-8xl font-extrabold font-outfit mb-8 text-white tracking-tighter leading-[0.9]">
                Stop Thinking. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-500">Start Deciding.</span>
              </h2>
              
              {/* AI GENERATOR INPUT */}
              <div className="max-w-xl mx-auto mt-12 mb-16">
                <form onSubmit={handleAIGenerate} className="relative group">
                  <div className="absolute inset-0 bg-indigo-600/20 blur-xl group-focus-within:bg-indigo-600/40 transition-all rounded-full"></div>
                  <div className="relative flex items-center bg-slate-900 border border-slate-700 rounded-2xl p-2 pl-6 focus-within:border-indigo-500 transition-all shadow-2xl">
                    <Search className="text-slate-500 mr-3" size={20} />
                    <input 
                      type="text"
                      value={aiInput}
                      onChange={(e) => setAiInput(e.target.value)}
                      placeholder="Type any hobby (e.g. Drones, Camping, Watches)..."
                      className="bg-transparent border-none outline-none text-white w-full py-3 placeholder:text-slate-600 font-medium"
                    />
                    <button 
                      type="submit"
                      disabled={loadingAI || !aiInput.trim()}
                      className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0"
                    >
                      {loadingAI ? <Loader2 className="animate-spin" size={18} /> : <>Generate <Sparkles size={16} /></>}
                    </button>
                  </div>
                  <p className="mt-4 text-slate-500 text-xs font-medium uppercase tracking-widest">
                    AI will build a unique logic tree for any product category
                  </p>
                </form>
              </div>
            </div>

            {/* Static Categories */}
            <div className="mb-8 flex items-center justify-between">
               <h3 className="text-sm font-black text-slate-500 uppercase tracking-[0.3em]">Featured Hubs</h3>
               <div className="h-px bg-slate-900 flex-1 ml-6"></div>
            </div>
            <div className="grid md:grid-cols-3 gap-8 mb-20">
              {allCategories.map(category => (
                <CategoryCard 
                  key={category.id} 
                  category={category} 
                  onSelect={handleCategorySelect} 
                />
              ))}
            </div>
            
            <div className="glass-card p-12 rounded-[3rem] border-dashed border-2 border-slate-800 text-center relative overflow-hidden group hover:border-indigo-500 transition-colors">
               <div className="absolute inset-0 bg-indigo-500/5 blur-3xl rounded-full translate-y-1/2"></div>
               <div className="relative z-10">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-slate-900 rounded-full border border-slate-800 group-hover:scale-110 transition-transform">
                    <PlusCircle className="text-indigo-500 w-10 h-10" />
                  </div>
                </div>
                <h4 className="text-2xl font-bold text-white font-outfit mb-3">Infinite Possibilities</h4>
                <p className="text-slate-500 mb-8 max-w-md mx-auto">Use the AI Lab at the top to generate a decision tree for literally anything. No more research fatigue.</p>
               </div>
            </div>
          </div>
        ) : (
          <div className="animate-fade-in max-w-3xl mx-auto">
            <div className="mb-12 flex items-center justify-between">
              <button 
                onClick={handleBack}
                className="flex items-center gap-2 text-slate-500 hover:text-white transition-all group font-bold text-sm uppercase tracking-widest"
              >
                <ChevronLeft className="group-hover:-translate-x-1 transition-transform" /> Back
              </button>
              <div className="flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-slate-900/50 border border-indigo-500/20 shadow-inner backdrop-blur-md">
                <span className="text-2xl">{activeCategory?.icon}</span>
                <span className="text-xs font-black text-indigo-400 uppercase tracking-widest">{activeCategory?.name}</span>
                {activeCategory?.id.startsWith('dynamic-') && (
                  <span className="text-[10px] bg-indigo-600/20 text-indigo-400 px-1.5 py-0.5 rounded border border-indigo-500/20">AI GEN</span>
                )}
              </div>
            </div>

            {activeNode?.type === NodeType.QUESTION ? (
              <div className="glass-card p-10 md:p-16 rounded-[3rem] border-indigo-500/20 shadow-2xl relative overflow-hidden">
                <div className="absolute -top-32 -right-32 w-80 h-80 bg-indigo-600/10 blur-[120px] rounded-full"></div>
                
                <div className="relative z-10">
                  <div className="mb-12">
                    <div className="flex items-center gap-4 mb-8">
                      <div className="h-1.5 w-16 bg-indigo-600 rounded-full shadow-[0_0_20px_rgba(99,102,241,0.5)]"></div>
                      <span className="text-indigo-400 font-black text-xs uppercase tracking-[0.3em]">Module {state.history.length + 1}</span>
                    </div>
                    <h3 className="text-3xl md:text-5xl font-extrabold text-white font-outfit leading-tight tracking-tight">
                      {activeNode.question}
                    </h3>
                  </div>

                  <div className="grid gap-4">
                    {activeNode.choices?.map((choice, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleChoiceSelect(choice.nextNodeId, choice.scoreImpact)}
                        className="group relative flex items-center justify-between p-7 rounded-2xl bg-white/5 border border-white/10 text-left transition-all hover:bg-indigo-600 hover:border-indigo-400 hover:translate-y-[-4px] shadow-lg active:scale-95"
                      >
                        <div className="flex flex-col pr-8">
                          <span className="text-xl font-bold text-white leading-tight">
                            {choice.label}
                          </span>
                          {choice.description && (
                            <span className="text-sm text-slate-400 group-hover:text-indigo-100 mt-2 font-medium">
                              {choice.description}
                            </span>
                          )}
                        </div>
                        <ChevronRight className="text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all flex-shrink-0" size={28} />
                      </button>
                    ))}
                  </div>

                  <div className="mt-16 flex justify-between items-center text-[10px] text-slate-600 font-black uppercase tracking-[0.2em]">
                    <span>Analysis Completion</span>
                    <span className="text-slate-400">{Math.round(((state.history.length + 1) / 4) * 100)}% Complete</span>
                  </div>
                  <div className="mt-4 w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-white/5">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-600 to-purple-500 transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(99,102,241,0.5)]"
                      style={{ width: `${Math.min(100, (state.history.length + 1) * 25)}%` }}
                    />
                  </div>
                </div>
              </div>
            ) : activeNode ? (
              <VerdictView node={activeNode} onReset={handleReset} />
            ) : (
              <div className="text-center py-20 bg-slate-900/50 rounded-3xl border border-rose-500/20">
                <AlertCircle className="mx-auto mb-4 text-rose-500" size={64} />
                <h3 className="text-2xl font-bold text-white mb-2">Matrix Out of Sync</h3>
                <p className="text-slate-400 mb-8">We couldn't determine the next node in the decision tree.</p>
                <button onClick={handleReset} className="px-8 py-3 bg-white/10 rounded-xl hover:bg-white/20 transition-all text-white font-bold">Restart Hub</button>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="py-16 px-6 border-t border-slate-900/50 bg-slate-950">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex flex-col items-center md:items-start gap-3">
            <div className="flex items-center gap-3 grayscale opacity-30">
              <Zap className="w-6 h-6" />
              <span className="font-outfit font-extrabold tracking-tighter text-xl text-white">THE DECIDER</span>
            </div>
            <p className="text-slate-600 text-xs mt-2 text-center md:text-left max-w-xs">
              Precision logic combined with AI intelligence to help you spend less time browsing and more time doing.
            </p>
          </div>
          <div className="flex flex-col items-center md:items-end gap-6">
            <div className="flex gap-10 text-slate-500 text-sm font-bold uppercase tracking-widest">
              <a href="#" className="hover:text-indigo-400 transition-colors">Terms</a>
              <a href="#" className="hover:text-indigo-400 transition-colors">Privacy</a>
              <a href="#" className="hover:text-indigo-400 transition-colors">API</a>
            </div>
            <p className="text-slate-700 text-[10px] font-medium italic">
              © {new Date().getFullYear()} Precision Decision Labs.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Separate component for clarity
const VerdictView: React.FC<{ node: QuizNode; onReset: () => void }> = ({ node, onReset }) => {
  const getStyle = () => {
    switch (node.verdictLevel) {
      case VerdictLevel.BUY: return { color: 'text-emerald-400', bg: 'bg-emerald-500/5', border: 'border-emerald-500/30', icon: <ShoppingBag className="w-8 h-8 text-emerald-500" /> };
      case VerdictLevel.WAIT: return { color: 'text-amber-400', bg: 'bg-amber-500/5', border: 'border-amber-500/30', icon: <Clock className="w-8 h-8 text-amber-500" /> };
      case VerdictLevel.SAVE: return { color: 'text-rose-400', bg: 'bg-rose-500/5', border: 'border-rose-500/30', icon: <ShieldX className="w-8 h-8 text-rose-500" /> };
      default: return { color: 'text-white', bg: 'bg-white/5', border: 'border-white/10', icon: <Info className="w-8 h-8 text-white" /> };
    }
  };

  const styles = getStyle();

  return (
    <div className="animate-fade-in w-full max-w-2xl mx-auto py-6">
      <div className={`p-10 md:p-14 rounded-[3rem] ${styles.bg} border ${styles.border} mb-12 shadow-2xl relative overflow-hidden`}>
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
          {styles.icon}
        </div>
        <div className="flex items-center gap-5 mb-8">
          <div className="p-4 bg-slate-950/80 rounded-2xl border border-white/5 shadow-xl">
            {styles.icon}
          </div>
          <div>
            <span className={`text-xs font-black uppercase tracking-[0.3em] ${styles.color}`}>Decision Outcome</span>
            <h2 className="text-3xl md:text-4xl font-extrabold font-outfit text-white leading-tight mt-1">{node.title}</h2>
          </div>
        </div>
        <p className="text-slate-300 leading-relaxed mb-12 text-lg md:text-xl font-medium opacity-90">
          {node.content}
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <button 
            onClick={onReset}
            className="flex-1 flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 text-white font-bold py-4 px-6 rounded-2xl border border-white/10 transition-all group"
          >
            <RotateCcw size={20} className="group-hover:rotate-[-45deg] transition-transform" /> Try Different Path
          </button>
          {node.verdictLevel === VerdictLevel.BUY && (
            <button 
              onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-6 rounded-2xl shadow-xl shadow-indigo-950 transition-all flex items-center justify-center gap-2"
            >
              See Recommendations <ArrowRight size={20} />
            </button>
          )}
        </div>
      </div>

      <AffiliateBlock recommendations={node.recommendations || []} />
    </div>
  );
};
